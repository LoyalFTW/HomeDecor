local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Achievements = NS.Data.Achievements or {}

NS.Data.Achievements["Pandaria"] = NS.Data.Achievements["Pandaria"] or {}

NS.Data.Achievements["Pandaria"]["Pandaria"] = {
  { decorID=767, source={ type="achievement" } },
  { decorID=11453, source={ type="achievement" } },
  { decorID=11456, source={ type="achievement" } },
  { decorID=11457, source={ type="achievement" } },
}
