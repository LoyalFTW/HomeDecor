local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Achievements = NS.Data.Achievements or {}

NS.Data.Achievements["Shadowlands"] = NS.Data.Achievements["Shadowlands"] or {}

NS.Data.Achievements["Shadowlands"]["TheShadowlands"] = {
  { decorID=4181, source={ type="achievement" } },
}
