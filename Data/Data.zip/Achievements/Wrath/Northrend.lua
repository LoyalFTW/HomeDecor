local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Achievements = NS.Data.Achievements or {}

NS.Data.Achievements["Wrath"] = NS.Data.Achievements["Wrath"] or {}

NS.Data.Achievements["Wrath"]["Northrend"] = {
  { decorID=4839, source={ type="achievement" } },
}
