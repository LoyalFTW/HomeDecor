local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Achievements = NS.Data.Achievements or {}

NS.Data.Achievements["Legion"] = NS.Data.Achievements["Legion"] or {}

NS.Data.Achievements["Legion"]["ClassHalls"] = {
  { decorID=5575, source={ type="achievement" } },
  { decorID=5879, source={ type="achievement" } },
  { decorID=5882, source={ type="achievement" } },
  { decorID=5888, source={ type="achievement" } },
  { decorID=14361, source={ type="achievement" } },
}
