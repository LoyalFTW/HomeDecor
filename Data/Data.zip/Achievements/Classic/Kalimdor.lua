local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Achievements = NS.Data.Achievements or {}

NS.Data.Achievements["Classic"] = NS.Data.Achievements["Classic"] or {}

NS.Data.Achievements["Classic"]["Kalimdor"] = {
  { decorID=857, source={ type="achievement" } },
  { decorID=1674, source={ type="achievement" } },
  { decorID=3867, source={ type="achievement" } },
  { decorID=3880, source={ type="achievement" } },
  { decorID=3881, source={ type="achievement" } },
  { decorID=3885, source={ type="achievement" } },
  { decorID=3887, source={ type="achievement" } },
  { decorID=3890, source={ type="achievement" } },
  { decorID=3893, source={ type="achievement" } },
  { decorID=3896, source={ type="achievement" } },
  { decorID=3897, source={ type="achievement" } },
  { decorID=3898, source={ type="achievement" } },
  { decorID=3899, source={ type="achievement" } },
  { decorID=3900, source={ type="achievement" } },
  { decorID=3902, source={ type="achievement" } },
  { decorID=3903, source={ type="achievement" } },
  { decorID=3905, source={ type="achievement" } },
  { decorID=3906, source={ type="achievement" } },
  { decorID=3907, source={ type="achievement" } },
  { decorID=4841, source={ type="achievement" } },
  { decorID=9244, source={ type="achievement" } },
  { decorID=11296, source={ type="achievement" } },
}
