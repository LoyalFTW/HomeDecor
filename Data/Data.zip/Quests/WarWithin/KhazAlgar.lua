local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Quests = NS.Data.Quests or {}

NS.Data.Quests["WarWithin"] = NS.Data.Quests["WarWithin"] or {}

NS.Data.Quests["WarWithin"]["KhazAlgar"] = {
  { decorID=825, source={ type="quest" } },
  { decorID=827, source={ type="quest" } },
  { decorID=1266, source={ type="quest" } },
  { decorID=1267, source={ type="quest" } },
  { decorID=1274, source={ type="quest" } },
  { decorID=1276, source={ type="quest" } },
  { decorID=1693, source={ type="quest" } },
  { decorID=2330, source={ type="quest" } },
  { decorID=4029, source={ type="quest" } },
  { decorID=4172, source={ type="quest" } },
  { decorID=9168, source={ type="quest" } },
  { decorID=9178, source={ type="quest" } },
  { decorID=9182, source={ type="quest" } },
  { decorID=9188, source={ type="quest" } },
  { decorID=9246, source={ type="quest" } },
  { decorID=9247, source={ type="quest" } },
  { decorID=14381, source={ type="quest" } },
}
