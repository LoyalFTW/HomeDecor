local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Quests = NS.Data.Quests or {}

NS.Data.Quests["Warlords"] = NS.Data.Quests["Warlords"] or {}

NS.Data.Quests["Warlords"]["Draenor"] = {
  { decorID=928, source={ type="quest" } },
  { decorID=8177, source={ type="quest" } },
  { decorID=8186, source={ type="quest" } },
  { decorID=8187, source={ type="quest" } },
  { decorID=8239, source={ type="quest" } },
  { decorID=8240, source={ type="quest" } },
  { decorID=8772, source={ type="quest" } },
  { decorID=8785, source={ type="quest" } },
  { decorID=8786, source={ type="quest" } },
}
