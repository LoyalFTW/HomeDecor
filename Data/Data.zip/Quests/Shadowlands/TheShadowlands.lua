local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Quests = NS.Data.Quests or {}

NS.Data.Quests["Shadowlands"] = NS.Data.Quests["Shadowlands"] or {}

NS.Data.Quests["Shadowlands"]["TheShadowlands"] = {
  { decorID=3869, source={ type="quest" } },
  { decorID=15605, source={ type="quest" } },
}
