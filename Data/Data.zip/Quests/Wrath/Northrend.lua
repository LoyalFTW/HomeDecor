local ADDON, NS = ...

NS.Data = NS.Data or {}
NS.Data.Quests = NS.Data.Quests or {}

NS.Data.Quests["Wrath"] = NS.Data.Quests["Wrath"] or {}

NS.Data.Quests["Wrath"]["Northrend"] = {
  { decorID=4448, source={ type="quest" } },
}
